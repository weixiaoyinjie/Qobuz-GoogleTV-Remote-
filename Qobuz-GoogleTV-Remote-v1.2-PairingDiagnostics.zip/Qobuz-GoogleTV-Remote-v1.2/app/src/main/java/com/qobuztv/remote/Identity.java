package com.qobuztv.remote;

import android.content.Context;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Date;

/** App-private stable client identity. Never exported, never backed up. */
final class Identity {
    private static final String ALIAS = "phone";
    private static final char[] PASSWORD = "local-device-key".toCharArray();
    final KeyStore keyStore;
    final X509Certificate cert;

    Identity(Context context) throws Exception {
        File keyFile = new File(context.getFilesDir(), "tv_remote_identity.p12");
        KeyStore ks = KeyStore.getInstance("PKCS12");
        if (keyFile.isFile()) {
            try (FileInputStream in = new FileInputStream(keyFile)) { ks.load(in, PASSWORD); }
        } else {
            KeyPairGenerator keygen = KeyPairGenerator.getInstance("RSA");
            keygen.initialize(2048, new SecureRandom());
            KeyPair pair = keygen.generateKeyPair();
            Date now = new Date(System.currentTimeMillis() - 60_000L);
            Date expiry = new Date(System.currentTimeMillis() + 10L * 365 * 24 * 3600 * 1000);
            X500Name owner = new X500Name("CN=Qobuz Google TV Remote");
            ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(pair.getPrivate());
            X509CertificateHolder holder = new JcaX509v3CertificateBuilder(
                    owner, new BigInteger(96, new SecureRandom()), now, expiry, owner, pair.getPublic())
                    .build(signer);
            X509Certificate generated = new JcaX509CertificateConverter().getCertificate(holder);
            ks.load(null, PASSWORD);
            ks.setKeyEntry(ALIAS, pair.getPrivate(), PASSWORD, new java.security.cert.Certificate[]{generated});
            File temp = new File(context.getFilesDir(), "tv_remote_identity.tmp");
            try (FileOutputStream out = new FileOutputStream(temp)) { ks.store(out, PASSWORD); }
            if (!temp.renameTo(keyFile)) throw new IllegalStateException("Unable to store device identity");
        }
        keyStore = ks;
        cert = (X509Certificate) ks.getCertificate(ALIAS);
        if (cert == null) throw new IllegalStateException("Missing device certificate");
    }

    static byte[] unsigned(BigInteger b) {
        byte[] bytes = b.toByteArray();
        if (bytes.length > 1 && bytes[0] == 0) {
            byte[] noSign = new byte[bytes.length - 1];
            System.arraycopy(bytes, 1, noSign, 0, noSign.length);
            return noSign;
        }
        return bytes;
    }
}

package com.qobuztv.remote;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Remote-only controller plus an explicit handoff to official Qobuz Connect. */
public class MainActivity extends Activity implements TvRemote.Callbacks {
    private static final int BACKGROUND = 0xff101217;
    private static final int CARD = 0xff1d2129;
    private static final int BUTTON = 0xff303741;
    private static final int ACCENT = 0xffd64542;
    private static final int TEXT = 0xfff7f8fb;
    private static final int SECONDARY = 0xffaeb6c4;

    private TvRemote tv;
    private final ExecutorService diagnostics = Executors.newSingleThreadExecutor();
    private SharedPreferences settings;
    private TextView status;
    private EditText ipBox;
    private EditText codeBox;
    private LinearLayout codeArea;
    private LinearLayout discoveries;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener finder;
    private WifiManager.MulticastLock multicast;
    private String lastName = "";
    private boolean scanActive = false;
    private boolean resolving = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        settings = getSharedPreferences("tv", MODE_PRIVATE);
        lastName = settings.getString("name", "");
        tv = new TvRemote(this, this);
        buildLayout();
        String previous = settings.getString("ip", "");
        if (!previous.isEmpty()) {
            ipBox.setText(previous);
            if (tv.isPaired()) tv.connect(previous);
        }
        startDiscovery();
    }

    private void buildLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout root = vertical(16);
        root.setPadding(dp(18), dp(24), dp(18), dp(30));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = label("QOBUZ · GOOGLE TV", 14, ACCENT, true);
        root.addView(brand);
        TextView heading = label("音乐遥控器", 30, TEXT, true);
        root.addView(heading);
        root.addView(label("手机遥控电视播放｜同一局域网｜无需 API 密钥", 13, SECONDARY, false));

        status = label("正在准备连接…", 14, TEXT, true);
        status.setPadding(dp(14), dp(13), dp(14), dp(13));
        status.setBackground(shape(CARD, 14));
        root.addView(status, full());

        LinearLayout qobuz = section(root, "Qobuz 直达");
        rowButtons(qobuz, new String[]{"♫ 打开手机 Qobuz", "TV 启动 Qobuz"},
                new Runnable[]{this::openPhoneQobuz, tv::launchQobuz}, true);
        qobuz.addView(label("用手机官方 Qobuz 的“音频输出”选择 Google TV 后，可选歌、播放列表和专辑。", 12, SECONDARY, false));

        LinearLayout connection = section(root, "连接电视 · 首次只需配对一次");
        ipBox = new EditText(this);
        ipBox.setSingleLine(true);
        ipBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        ipBox.setHint("电视 IP，如 192.168.1.120");
        ipBox.setHintTextColor(0xff8a929d);
        ipBox.setTextColor(TEXT);
        ipBox.setTextSize(16);
        ipBox.setPadding(dp(14), dp(9), dp(14), dp(9));
        ipBox.setBackground(shape(BUTTON, 12));
        connection.addView(ipBox, full());
        rowButtons(connection, new String[]{"搜索电视", "首次配对", "重新连接"},
                new Runnable[]{this::startDiscovery, this::startPair, this::connectNow}, false);
        rowButtons(connection, new String[]{"兼容模式配对", "取消配对", "复制配对诊断"},
                new Runnable[]{this::startCompatPair, tv::cancelPairing, this::copyDiagnostics}, false);
        rowButtons(connection, new String[]{"检测端口 6467 / 6466"},
                new Runnable[]{this::testRemotePorts}, false);

        codeArea = vertical(10);
        codeBox = new EditText(this);
        codeBox.setTextColor(TEXT);
        codeBox.setTextSize(20);
        codeBox.setAllCaps(true);
        codeBox.setSingleLine(true);
        codeBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        codeBox.setHint("电视显示的 6 位十六进制配对码");
        codeBox.setHintTextColor(SECONDARY);
        codeBox.setBackground(shape(BUTTON, 10));
        codeBox.setPadding(dp(13), dp(10), dp(13), dp(10));
        codeArea.addView(codeBox, full());
        codeArea.addView(action("确认验证码", true, () -> tv.submitCode(codeBox.getText().toString().trim())), full());
        codeArea.setVisibility(View.GONE);
        connection.addView(codeArea);
        discoveries = vertical(6);
        connection.addView(discoveries);

        LinearLayout playback = section(root, "Qobuz 播放控制");
        rowButtons(playback, new String[]{"⏮ 上一首", "⏯ 播放 / 暂停", "⏭ 下一首"},
                new Runnable[]{() -> tv.key(TvRemote.PREVIOUS), () -> tv.key(TvRemote.PLAY_PAUSE), () -> tv.key(TvRemote.NEXT)}, true);
        rowButtons(playback, new String[]{"－ 音量", "🔇 静音", "＋ 音量"},
                new Runnable[]{() -> tv.key(TvRemote.VOL_DOWN), () -> tv.key(TvRemote.MUTE), () -> tv.key(TvRemote.VOL_UP)}, false);

        LinearLayout navigation = section(root, "电视菜单导航");
        addPad(navigation);
        rowButtons(navigation, new String[]{"⌂ 主页", "← 返回", "清除配对"},
                new Runnable[]{() -> tv.key(TvRemote.HOME), () -> tv.key(TvRemote.BACK), () -> {
                    tv.unpair(); Toast.makeText(this, "配对记录已清除", Toast.LENGTH_SHORT).show();
                }}, false);

        LinearLayout help = section(root, "使用提示");
        help.addView(label("① 手机与 Google TV 连接同一路由器/Wi-Fi。\n② 搜索电视，选择设备，再点击“首次配对”，输入电视上的 6 位码。\n③ 电视安装并登录 Qobuz，打开后用播放键控制。\n④ 想在手机挑歌曲：打开官方 Qobuz，选择输出设备 Google TV。\n⑤ 如果电视 IP 变化，重新搜索并选择相同的电视即可。", 13, SECONDARY, false));
        help.addView(label("【官方 Google Home 能弹码，但本 App 不能？】\n电视端服务基本正常，无需重置电视或清除 Remote Service 数据。\n① 先确认选择的 IP 与官方 Google Home 控制的是同一台电视。\n② 用“首次配对”；若没有弹码，试“兼容模式配对”。\n③ 再点击“复制配对诊断”，把信息发给开发者定位具体握手阶段。\n注意：每个独立遥控 App 都需要自己配对；不能直接借用 Google Home 的密钥。", 12, SECONDARY, false));
        help.addView(label("说明：这是独立的局域网遥控工具，并非 Qobuz 官方应用。启动 TV 应用的快捷指令因固件而异；音乐搜索、封面和曲库由 Qobuz 官方 App 提供。", 12, SECONDARY, false));
    }

    private void addPad(LinearLayout section) {
        LinearLayout top = centered();
        top.addView(keyButton("▲", TvRemote.UP));
        section.addView(top, full());
        LinearLayout center = centered();
        center.addView(keyButton("◀", TvRemote.LEFT));
        Button ok = keyButton("OK", TvRemote.SELECT);
        ok.setBackground(shape(ACCENT, 18));
        center.addView(ok);
        center.addView(keyButton("▶", TvRemote.RIGHT));
        section.addView(center, full());
        LinearLayout bottom = centered();
        bottom.addView(keyButton("▼", TvRemote.DOWN));
        section.addView(bottom, full());
    }

    private Button keyButton(String name, int key) {
        Button b = action(name, false, () -> tv.key(key));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(78), dp(56));
        params.setMargins(dp(4), dp(3), dp(4), dp(3));
        b.setLayoutParams(params);
        return b;
    }

    private LinearLayout section(LinearLayout root, String title) {
        LinearLayout box = vertical(10);
        box.setPadding(dp(15), dp(16), dp(15), dp(16));
        box.setBackground(shape(CARD, 16));
        box.addView(label(title, 16, TEXT, true));
        root.addView(box, full());
        return box;
    }

    private void rowButtons(LinearLayout holder, String[] titles, Runnable[] actions, boolean prominent) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        for (int i = 0; i < titles.length; i++) {
            Button b = action(titles[i], prominent && i == 0, actions[i]);
            b.setTextSize(titles[i].length() > 8 ? 11 : 12);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(52), 1f);
            params.setMargins(dp(2), 0, dp(2), 0);
            bar.addView(b, params);
        }
        holder.addView(bar, full());
    }

    private Button action(String text, boolean primary, Runnable onTap) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextSize(13);
        b.setTextColor(TEXT);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(4), dp(2), dp(4), dp(2));
        b.setBackground(shape(primary ? ACCENT : BUTTON, 12));
        b.setOnClickListener(v -> onTap.run());
        return b;
    }

    private LinearLayout vertical(int spacing) {
        LinearLayout result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        result.setGravity(Gravity.CENTER_VERTICAL);
        result.setClipToPadding(false);
        // Spacing is handled by explicit section padding and margins.
        return result;
    }

    private LinearLayout centered() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        return row;
    }

    private TextView label(String value, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setLineSpacing(dp(3), 1.06f);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setPadding(dp(0), dp(6), dp(0), dp(6));
        return tv;
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private LinearLayout.LayoutParams full() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(6));
        return lp;
    }
    private int dp(float x) { return (int) (getResources().getDisplayMetrics().density * x + 0.5f); }

    private String host() {
        String input = ipBox.getText().toString().trim();
        if (input.isEmpty() || input.contains("/") || input.contains(":") || input.contains(" ")) {
            status.setText("请先输入电视的 IPv4 地址，或通过搜索电视选择设备。");
            return null;
        }
        settings.edit().putString("ip", input).apply();
        return input;
    }
    private void startPair() { String ip = host(); if (ip != null) tv.pair(ip); }
    private void startCompatPair() { String ip = host(); if (ip != null) tv.pairCompatibility(ip); }
    private void copyDiagnostics() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard == null) { status.setText("无法访问剪贴板"); return; }
        clipboard.setPrimaryClip(ClipData.newPlainText("Qobuz TV pairing diagnostics", tv.diagnosticLog()));
        Toast.makeText(this, "配对诊断已复制；不会包含验证码或私钥", Toast.LENGTH_LONG).show();
    }
    private void connectNow() { String ip = host(); if (ip != null) tv.connect(ip); }

    private void testRemotePorts() {
        String ip = host();
        if (ip == null) return;
        status.setText("正在测试电视 " + ip + " 的遥控服务端口…");
        diagnostics.execute(() -> {
            boolean pairing = canConnect(ip, 6467);
            boolean control = canConnect(ip, 6466);
            String report = "电视 " + ip + " | 配对 6467: " + (pairing ? "可连接" : "无法连接")
                    + " | 遥控 6466: " + (control ? "可连接" : "无法连接")
                    + (pairing ? "。6467 已开放；若验证码仍未显示，先用 Google TV 官方遥控器测试配对。"
                               : "。6467 无法访问，请检查 IP、Wi-Fi 隔离及电视 Android TV Remote Service。");
            runOnUiThread(() -> { if (!isFinishing()) status.setText(report); });
        });
    }

    private static boolean canConnect(String host, int port) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), 2500);
            return true;
        } catch (Exception ignored) { return false; }
    }

    private void openPhoneQobuz() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.qobuz.music");
        if (launch != null) {
            try { startActivity(launch); return; }
            catch (Exception ignored) {}
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.qobuz.music"))); }
        catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.qobuz.music")));
        }
    }

    @Override public void message(String msg) { status.setText(msg); }
    @Override public void codeNeeded() { codeArea.setVisibility(View.VISIBLE); codeBox.requestFocus(); }
    @Override public void connected(boolean ready) {
        if (ready) codeArea.setVisibility(View.GONE);
    }
    @Override public void pairingDone() { codeArea.setVisibility(View.GONE); }

    private void startDiscovery() {
        stopDiscovery();
        discoveries.removeAllViews();
        discoveries.addView(label("正在搜索 Google TV…", 12, SECONDARY, false));
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null) {
                multicast = wifi.createMulticastLock("qobuz-tv-discovery");
                multicast.setReferenceCounted(false);
                multicast.acquire();
            }
            nsd = (NsdManager) getSystemService(NSD_SERVICE);
            if (nsd == null) throw new IllegalStateException("系统不支持电视搜索");
            finder = new NsdManager.DiscoveryListener() {
                @Override public void onDiscoveryStarted(String type) {
                    scanActive = true;
                    runOnUiThread(() -> status.setText("正在局域网查找电视…"));
                }
                @Override public void onServiceFound(NsdServiceInfo service) {
                    if (resolving) return;
                    resolving = true;
                    try {
                        nsd.resolveService(service, new NsdManager.ResolveListener() {
                            @Override public void onResolveFailed(NsdServiceInfo s, int code) { resolving = false; }
                            @Override public void onServiceResolved(NsdServiceInfo resolved) {
                                resolving = false;
                                if (resolved.getHost() == null) return;
                                String ip = resolved.getHost().getHostAddress();
                                String name = resolved.getServiceName();
                                if (ip == null || ip.contains(":")) return; // IPv4 only
                                runOnUiThread(() -> onDevice(name, ip));
                            }
                        });
                    } catch (Exception e) { resolving = false; }
                }
                @Override public void onServiceLost(NsdServiceInfo service) {}
                @Override public void onDiscoveryStopped(String type) { scanActive = false; }
                @Override public void onStartDiscoveryFailed(String type, int error) {
                    scanActive = false;
                    runOnUiThread(() -> status.setText("自动搜索失败，可手动输入电视 IP（" + error + "）"));
                    stopDiscovery();
                }
                @Override public void onStopDiscoveryFailed(String type, int code) { scanActive = false; }
            };
            nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, finder);
        } catch (Exception e) {
            status.setText("搜索不可用，可输入电视 IP：" + e.getMessage());
            stopDiscovery();
        }
    }

    private void onDevice(String name, String ip) {
        if (isFinishing() || isDestroyed()) return;
        for (int i = 0; i < discoveries.getChildCount(); i++) {
            View v = discoveries.getChildAt(i);
            if (ip.equals(v.getTag())) return;
        }
        if (discoveries.getChildCount() == 1 && discoveries.getChildAt(0).getTag() == null) {
            discoveries.removeAllViews();
        }
        Button found = action("📺 " + name + " · " + ip, false, () -> choose(name, ip));
        found.setTag(ip);
        discoveries.addView(found, full());
        if (!lastName.isEmpty() && name.equals(lastName) && tv.isPaired() && !ip.equals(settings.getString("ip", ""))) {
            choose(name, ip);
            tv.connect(ip);
        }
    }

    private void choose(String name, String ip) {
        ipBox.setText(ip);
        lastName = name;
        settings.edit().putString("name", name).putString("ip", ip).apply();
        status.setText("已选择 " + name + "，可配对或重新连接。");
    }

    private void stopDiscovery() {
        if (nsd != null && finder != null) {
            try { nsd.stopServiceDiscovery(finder); } catch (Exception ignored) {}
        }
        finder = null;
        scanActive = false;
        if (multicast != null) {
            try { if (multicast.isHeld()) multicast.release(); } catch (Exception ignored) {}
            multicast = null;
        }
    }

    @Override public void onDestroy() {
        stopDiscovery();
        tv.shutdown();
        diagnostics.shutdownNow();
        super.onDestroy();
    }
}

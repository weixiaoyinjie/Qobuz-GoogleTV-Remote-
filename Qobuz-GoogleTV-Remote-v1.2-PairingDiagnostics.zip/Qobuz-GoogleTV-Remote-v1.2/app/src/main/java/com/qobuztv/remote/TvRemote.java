package com.qobuztv.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.IOException;
import android.util.Log;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

/** Native Android TV / Google TV Remote v2 protocol (LAN only, 6467/6466). */
final class TvRemote {
    interface Callbacks {
        void message(String msg);
        void codeNeeded();
        void connected(boolean ready);
        void pairingDone();
    }

    static final int PLAY_PAUSE = 85;
    static final int NEXT = 87;
    static final int PREVIOUS = 88;
    static final int VOL_UP = 24;
    static final int VOL_DOWN = 25;
    static final int MUTE = 164;
    static final int HOME = 3;
    static final int BACK = 4;
    static final int UP = 19;
    static final int DOWN = 20;
    static final int LEFT = 21;
    static final int RIGHT = 22;
    static final int SELECT = 23;

    private final Context context;
    private final SharedPreferences prefs;
    private final Callbacks callback;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService tasks = Executors.newSingleThreadExecutor();
    private final ExecutorService outbound = Executors.newSingleThreadExecutor();
    private final BlockingQueue<String> codeQueue = new ArrayBlockingQueue<>(1);
    private volatile SSLSocket active;
    private volatile boolean ready;
    private volatile boolean closed;
    private Identity identity;
    private final AtomicBoolean pairing = new AtomicBoolean(false);
    private final StringBuilder diagnostics = new StringBuilder();

    /** Public diagnostics intentionally exclude the PIN, private key and pairing proof. */
    synchronized String diagnosticLog() { return diagnostics.toString(); }
    private synchronized void record(String line) {
        if (diagnostics.length() > 12000) diagnostics.delete(0, diagnostics.length() - 8000);
        diagnostics.append(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US)
                .format(new java.util.Date())).append("  ").append(line).append('\n');
        Log.d("QobuzTV-Pair", line);
    }

    TvRemote(Context context, Callbacks callback) {
        this.context = context.getApplicationContext();
        this.prefs = context.getSharedPreferences("tv", Context.MODE_PRIVATE);
        this.callback = callback;
    }

    private void status(String text) { record(text); main.post(() -> callback.message(text)); }
    private void setReady(boolean state) {
        ready = state;
        main.post(() -> callback.connected(state));
    }
    boolean isReady() { return ready; }
    boolean isPaired() { return !prefs.getString("tvcert", "").isEmpty(); }

    /**
     * The app needs its OWN pairing: Google's Home credentials cannot be reused.
     * Normal mode uses the service identifier tested by atvremote clients;
     * compatibility mode uses the alternate identifier used by other v2 clients.
     */
    void pair(String host) { pairWithService(host, "atvremote"); }
    void pairCompatibility(String host) { pairWithService(host, "androidtv-remote"); }

    private void pairWithService(String host, String serviceName) {
        if (!pairing.compareAndSet(false, true)) {
            status("已有配对流程正在运行，请完成或等候当前流程结束。");
            return;
        }
        tasks.execute(() -> {
            try {
                codeQueue.clear();
                status("配对开始：目标 " + host + ", 服务标识 " + serviceName);
                if (identity == null) identity = new Identity(context);
                try (SSLSocket s = open(host, 6467)) {
                    s.setSoTimeout(14_000);
                    status("阶段 1/4：TLS 握手成功，准备发送配对请求");
                    X509Certificate tvCert = (X509Certificate) s.getSession().getPeerCertificates()[0];
                    Wire.send(s.getOutputStream(), polo(10, new Wire.Msg()
                            .text(1, serviceName).text(2, "Qobuz TV Remote")));
                    status("阶段 2/4：已发送请求，等待电视的 PairingRequestAck (11)");

                    boolean configured = false;
                    boolean optionsSent = false;
                    boolean configSent = false;
                    for (int frames = 0; frames < 12 && !configured; frames++) {
                        Wire.Parsed incoming = Wire.recv(s.getInputStream());
                        record("电视协议回应字段: " + incoming.buffers.keySet()
                                + " 状态=" + incoming.number(2, -1));
                        validateStatus(incoming);
                        if (incoming.has(11) && !optionsSent) {
                            status("阶段 3/4：电视已确认请求 (11)，协商 6 位十六进制码");
                            Wire.Msg enc = new Wire.Msg().num(1, 3).num(2, 6);
                            Wire.send(s.getOutputStream(), polo(20, new Wire.Msg()
                                    .nested(1, enc).num(3, 1)));
                            optionsSent = true;
                        } else if ((incoming.has(20) || incoming.has(21)) && optionsSent && !configSent) {
                            status("阶段 3/4：电视已返回配对选项，发送 Configuration (30)");
                            Wire.Msg enc = new Wire.Msg().num(1, 3).num(2, 6);
                            Wire.send(s.getOutputStream(), polo(30, new Wire.Msg()
                                    .nested(1, enc).num(2, 1)));
                            configSent = true;
                        } else if (incoming.has(31) && configSent) {
                            configured = true;
                        } else {
                            throw new IOException("配对握手遇到意外回应字段 " + incoming.buffers.keySet()
                                    + "，请复制诊断信息");
                        }
                    }
                    if (!configured) throw new IOException("电视没有确认 Configuration (31)");
                    status("阶段 4/4：电视已经确认配置 (31)；现在应当在电视屏幕显示 6 位验证码");
                    main.post(callback::codeNeeded);
                    String code = codeQueue.poll(90, TimeUnit.SECONDS);
                    if (code == null) throw new IOException("等待验证码超时：如果电视未显示，请试试『兼容模式配对』并复制诊断");
                    // Deliberately do NOT log the code or the derived proof.
                    byte[] proof = pairingProof(identity.cert, tvCert, code);
                    Wire.send(s.getOutputStream(), polo(40, new Wire.Msg().bytes(1, proof)));
                    validateSecretReply(Wire.recv(s.getInputStream()));
                    prefs.edit().putString("tvcert", fingerprint(tvCert)).apply();
                    status("配对成功，正在连接电视遥控端口 6466…");
                    main.post(callback::pairingDone);
                }
                connect(host);
            } catch (Exception e) {
                status("配对失败：" + friendly(e) + "；可复制诊断信息查看失败阶段");
                setReady(false);
                main.post(callback::pairingDone); // Hide PIN input after a failed session.
            } finally {
                pairing.set(false);
            }
        });
    }

    void submitCode(String code) {
        if (!pairing.get()) { status("当前没有等待验证码的配对任务"); return; }
        codeQueue.clear();
        codeQueue.offer(code);
    }
    void cancelPairing() {
        if (!pairing.get()) { status("当前没有正在运行的配对任务"); return; }
        // Unblocks the PIN wait promptly; if still handshaking the sentinel will
        // be consumed on reaching PIN input. Never exposes or reuses a PIN.
        codeQueue.clear();
        codeQueue.offer("");
        status("已请求结束当前配对；请等错误提示出现后再开始新的配对");
    }

    void connect(String host) {
        tasks.execute(() -> {
            if (closed) return;
            if (!isPaired()) { status("先选择“首次配对”，输入电视上的验证码。"); return; }
            try {
                if (identity == null) identity = new Identity(context);
                dropActive();
                status("正在连接 " + host + " …");
                SSLSocket sock = open(host, 6466);
                String expected = prefs.getString("tvcert", "");
                String actual = fingerprint((X509Certificate) sock.getSession().getPeerCertificates()[0]);
                if (!actual.equals(expected)) {
                    sock.close();
                    throw new IOException("电视身份与已配对设备不同，请重新配对");
                }
                sock.setSoTimeout(15_000);
                active = sock;
                Thread reader = new Thread(() -> readLoop(sock), "QobuzTV-Reader");
                reader.setDaemon(true);
                reader.start();
            } catch (Exception e) {
                status("连接失败：" + friendly(e));
                setReady(false);
            }
        });
    }

    void key(int keycode) { send(new Wire.Msg().nested(10, new Wire.Msg().num(1, keycode).num(2, 3))); }

    /** Application launch via Remote v2 deep-link. Firmware support varies. */
    void launchQobuz() {
        send(new Wire.Msg().nested(90,
                new Wire.Msg().text(1, "market://launch?id=com.qobuz.music")));
        status("已尝试在电视启动 Qobuz；如没有反应，请使用方向键在电视主页打开。");
    }

    private void send(Wire.Msg command) {
        outbound.execute(() -> {
            SSLSocket s = active;
            if (!ready || s == null || s.isClosed()) {
                status("尚未连接电视，请先配对或重连。");
                return;
            }
            try { synchronized (s) { Wire.send(s.getOutputStream(), command); } }
            catch (IOException e) {
                status("发送失败：" + friendly(e));
                if (active == s) dropActive();
            }
        });
    }

    private void readLoop(SSLSocket s) {
        try {
            while (!closed && active == s) {
                Wire.Parsed msg = Wire.recv(s.getInputStream());
                if (msg.has(1)) {
                    Wire.Msg device = new Wire.Msg().num(3, 1)
                            .text(4, "1").text(5, "Qobuz TV Remote").text(6, "1.0");
                    sendHandshake(s, new Wire.Msg().nested(1,
                            new Wire.Msg().num(1, 1 | 2 | 32 | 64 | 512).nested(2, device)));
                } else if (msg.has(2)) {
                    sendHandshake(s, new Wire.Msg().nested(2,
                            new Wire.Msg().num(1, 1 | 2 | 32 | 64 | 512)));
                } else if (msg.has(8)) {
                    long pingValue = msg.inner(8).number(1, 0);
                    sendHandshake(s, new Wire.Msg().nested(9, new Wire.Msg().num(1, pingValue)));
                } else if (msg.has(40)) {
                    s.setSoTimeout(0);
                    setReady(true);
                    status("已连接 Google TV · 可以控制 Qobuz");
                }
            }
        } catch (Exception e) {
            if (active == s && !closed) status("电视连接已断开：" + friendly(e));
        } finally {
            if (active == s) dropActive();
            else { try { s.close(); } catch (IOException ignored) {} }
        }
    }

    private void sendHandshake(SSLSocket s, Wire.Msg data) throws IOException {
        // Read loop is sole writer until START; after START only pongs use this method.
        synchronized (s) { Wire.send(s.getOutputStream(), data); }
    }

    private void dropActive() {
        SSLSocket s = active;
        active = null;
        setReady(false);
        if (s != null) try { s.close(); } catch (IOException ignored) {}
    }

    void unpair() {
        dropActive();
        prefs.edit().remove("tvcert").apply();
        status("已清除本机配对记录。电视端如有残留配对，可从电视设置中删除。");
    }

    void shutdown() {
        closed = true;
        dropActive();
        tasks.shutdownNow();
        outbound.shutdownNow();
    }

    private SSLSocket open(String host, int port) throws Exception {
        KeyManagerFactory km = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        km.init(identity.keyStore, "local-device-key".toCharArray());
        X509TrustManager allowDuringPairing = new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            public void checkClientTrusted(X509Certificate[] certs, String auth) {}
            public void checkServerTrusted(X509Certificate[] certs, String auth) {}
        };
        SSLContext ssl = SSLContext.getInstance("TLS");
        ssl.init(km.getKeyManagers(), new javax.net.ssl.TrustManager[]{allowDuringPairing}, new SecureRandom());
        Socket raw = new Socket();
        try {
            raw.connect(new InetSocketAddress(host, port), 7000);
            raw.setSoTimeout(12_000);
            SSLSocket socket = (SSLSocket) ssl.getSocketFactory().createSocket(raw, host, port, true);
            socket.setUseClientMode(true);
            socket.startHandshake();
            return socket;
        } catch (Exception ex) {
            try { raw.close(); } catch (IOException ignored) {}
            throw ex;
        }
    }

    private static Wire.Msg polo(int type, Wire.Msg body) {
        return new Wire.Msg().num(1, 2).num(2, 200).nested(type, body);
    }

    private static void validateStatus(Wire.Parsed msg) throws IOException {
        long status = msg.number(2, 200);
        if (status != 200) throw new IOException("TV pairing status: " + status);
    }
    private static void validateSecretReply(Wire.Parsed msg) throws IOException {
        validateStatus(msg);
        if (!msg.has(41)) throw new IOException("电视没有接受验证码");
    }

    private static byte[] pairingProof(X509Certificate client, X509Certificate tv, String code) throws Exception {
        String hex = code.trim().toUpperCase(Locale.ROOT);
        if (!hex.matches("[0-9A-F]{6}")) throw new IOException("验证码必须是 6 位十六进制字符");
        RSAPublicKey a = (RSAPublicKey) client.getPublicKey();
        RSAPublicKey b = (RSAPublicKey) tv.getPublicKey();
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(Identity.unsigned(a.getModulus()));
        md.update(Identity.unsigned(a.getPublicExponent()));
        md.update(Identity.unsigned(b.getModulus()));
        md.update(Identity.unsigned(b.getPublicExponent()));
        for (int i = 2; i < hex.length(); i += 2) {
            md.update((byte) Integer.parseInt(hex.substring(i, i + 2), 16));
        }
        byte[] proof = md.digest();
        if ((proof[0] & 255) != Integer.parseInt(hex.substring(0, 2), 16)) {
            throw new IOException("验证码不匹配，请检查电视上显示的数字");
        }
        return proof;
    }

    private static String fingerprint(X509Certificate c) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(c.getEncoded());
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) sb.append(String.format(Locale.US, "%02x", b & 255));
        return sb.toString();
    }

    private static String friendly(Throwable e) {
        if (e instanceof java.net.SocketTimeoutException) return "连接或协议响应超时，请复制诊断记录以确认停在哪一步";
        if (e instanceof java.net.ConnectException) return "连接电视端口失败，检查电视 IP 和网络";
        String s = e.getMessage();
        return (s == null || s.trim().isEmpty()) ? e.getClass().getSimpleName() : s;
    }
}

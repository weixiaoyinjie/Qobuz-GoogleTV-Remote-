package com.qobuztv.remote;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Minimal bounded protobuf varint and length-delimited codec for Android TV Remote v2. */
final class Wire {
    private Wire() {}
    static final int MAX_FRAME = 1024 * 1024;

    static class Msg {
        private final ByteArrayOutputStream out = new ByteArrayOutputStream();
        Msg num(int field, long value) {
            putVar(out, (field << 3));
            putVar(out, value);
            return this;
        }
        Msg bytes(int field, byte[] value) {
            putVar(out, (field << 3) | 2);
            putVar(out, value.length);
            out.write(value, 0, value.length);
            return this;
        }
        Msg text(int field, String value) { return bytes(field, value.getBytes(StandardCharsets.UTF_8)); }
        Msg nested(int field, Msg value) { return bytes(field, value.data()); }
        byte[] data() { return out.toByteArray(); }
    }

    static class Parsed {
        final Map<Integer, Long> numbers = new HashMap<>();
        final Map<Integer, byte[]> buffers = new HashMap<>();
        boolean has(int field) { return numbers.containsKey(field) || buffers.containsKey(field); }
        long number(int field, long fallback) { return numbers.getOrDefault(field, fallback); }
        Parsed inner(int field) throws IOException {
            byte[] b = buffers.get(field);
            return b == null ? new Parsed() : parse(b);
        }
    }

    private static void putVar(OutputStream out, long value) {
        try {
            do {
                int b = (int) (value & 0x7f);
                value >>>= 7;
                out.write(value == 0 ? b : (b | 0x80));
            } while (value != 0);
        } catch (IOException e) { throw new IllegalStateException(e); }
    }

    static void send(OutputStream stream, Msg msg) throws IOException {
        byte[] payload = msg.data();
        if (payload.length > MAX_FRAME) throw new IOException("Message too large");
        putVar(stream, payload.length);
        stream.write(payload);
        stream.flush();
    }

    static Parsed recv(InputStream stream) throws IOException {
        long length = readVar(stream);
        if (length < 0 || length > MAX_FRAME) throw new IOException("Bad frame size: " + length);
        byte[] data = new byte[(int) length];
        int offset = 0;
        while (offset < data.length) {
            int n = stream.read(data, offset, data.length - offset);
            if (n < 0) throw new EOFException("Socket closed mid-frame");
            offset += n;
        }
        return parse(data);
    }

    private static long readVar(InputStream in) throws IOException {
        long value = 0;
        for (int shift = 0; shift <= 63; shift += 7) {
            int b = in.read();
            if (b == -1) throw new EOFException("Socket closed");
            value |= (long) (b & 127) << shift;
            if ((b & 128) == 0) return value;
        }
        throw new IOException("Invalid varint");
    }

    private static Parsed parse(byte[] data) throws IOException {
        Parsed result = new Parsed();
        int[] offset = {0};
        while (offset[0] < data.length) {
            long tag = fromArray(data, offset);
            int field = (int) (tag >>> 3);
            int kind = (int) (tag & 7);
            if (field == 0) throw new IOException("Invalid field number");
            switch (kind) {
                case 0: result.numbers.put(field, fromArray(data, offset)); break;
                case 2:
                    long len = fromArray(data, offset);
                    if (len < 0 || len > data.length - offset[0]) throw new IOException("Invalid message length");
                    byte[] sub = new byte[(int) len];
                    System.arraycopy(data, offset[0], sub, 0, sub.length);
                    offset[0] += sub.length;
                    result.buffers.put(field, sub);
                    break;
                case 1: offset[0] += 8; break;
                case 5: offset[0] += 4; break;
                default: throw new IOException("Unsupported protobuf wire type: " + kind);
            }
            if (offset[0] > data.length) throw new IOException("Truncated protobuf");
        }
        return result;
    }
    private static long fromArray(byte[] data, int[] pos) throws IOException {
        long value = 0;
        for (int shift = 0; shift <= 63; shift += 7) {
            if (pos[0] >= data.length) throw new EOFException("Truncated varint");
            int b = data[pos[0]++] & 255;
            value |= (long) (b & 127) << shift;
            if ((b & 128) == 0) return value;
        }
        throw new IOException("Invalid varint");
    }
}

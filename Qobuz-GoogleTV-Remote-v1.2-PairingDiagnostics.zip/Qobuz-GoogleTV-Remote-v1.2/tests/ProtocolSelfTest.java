package com.qobuztv.remote;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/** Byte-level regression checks; no TV connection or Android SDK required. */
public final class ProtocolSelfTest {
    private static void ok(boolean condition, String why) {
        if (!condition) throw new AssertionError(why);
    }
    public static void main(String[] args) throws Exception {
        Wire.Msg request = new Wire.Msg().num(1, 2).num(2, 200).nested(10,
                new Wire.Msg().text(1, "atvremote").text(2, "Qobuz TV Remote"));
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        Wire.send(bytes, request);
        Wire.Parsed parsed = Wire.recv(new ByteArrayInputStream(bytes.toByteArray()));
        ok(parsed.number(1, -1) == 2, "Protocol version must be 2");
        ok(parsed.number(2, -1) == 200, "Outer status must be 200");
        ok(parsed.has(10), "Pairing request field 10 required");
        ok(Arrays.equals(parsed.inner(10).buffers.get(1), "atvremote".getBytes("UTF-8")), "Service name");

        Wire.Msg option = new Wire.Msg().num(1, 2).num(2, 200).nested(20,
                new Wire.Msg().nested(1, new Wire.Msg().num(1, 3).num(2, 6)).num(3, 1));
        ByteArrayOutputStream ob = new ByteArrayOutputStream();
        Wire.send(ob, option);
        Wire.Parsed op = Wire.recv(new ByteArrayInputStream(ob.toByteArray())).inner(20);
        ok(op.inner(1).number(1, -1) == 3, "Hex encoding");
        ok(op.inner(1).number(2, -1) == 6, "6 hex digits");
        ok(op.number(3, -1) == 1, "Preferred role INPUT");

        Wire.Msg config = new Wire.Msg().num(1, 2).num(2, 200).nested(30,
                new Wire.Msg().nested(1, new Wire.Msg().num(1, 3).num(2, 6)).num(2, 1));
        ByteArrayOutputStream cb = new ByteArrayOutputStream();
        Wire.send(cb, config);
        Wire.Parsed cp = Wire.recv(new ByteArrayInputStream(cb.toByteArray())).inner(30);
        ok(cp.inner(1).number(2, -1) == 6, "Configuration PIN digits");
        ok(cp.number(2, -1) == 1, "Configuration role INPUT");

        Wire.Msg secret = new Wire.Msg().num(1, 2).num(2, 200).nested(40,
                new Wire.Msg().bytes(1, new byte[32]));
        ByteArrayOutputStream sb = new ByteArrayOutputStream();
        Wire.send(sb, secret);
        ok(Wire.recv(new ByteArrayInputStream(sb.toByteArray())).inner(40).buffers.get(1).length == 32,
                "Secret SHA256 length");
        System.out.println("Protocol wire format self-tests passed.");
    }
}

# Qobuz Google TV 遥控器（Android）

用于在 **同一局域网** 内控制 Android TV / Google TV 上的 Qobuz。**无需 Qobuz API 密钥、无需 Root、无需 ADB 调试**。

> 独立第三方工具，未与 Qobuz 或 Google 关联。使用 Google TV Remote v2 局域网控制协议（TCP/TLS 6466/6467），配对码由电视显示。Qobuz 曲库、专辑、搜索和 Hi-Res 选择使用 Qobuz 官方应用的 Qobuz Connect 完成，本应用不破解或代理 Qobuz 音频和账号。

## v1.2 配对流程兼容性更新与排错（2026-10-29）

- 已确认：如果 **Google Home 可显示配对码**，通常不需要修改电视端设置；本 App 必须单独配对，无法读取 Google Home 的配对凭证。
- 两种配对服务标识：标准 `atvremote` 与兼容 `androidtv-remote`，可以在 App 内切换重试。
- 增加每一步电视回应字段的诊断记录（发送配对请求 → 11 确认 → 20/21 选项 → 31 配置确认）。
- 新增“取消配对”和“复制配对诊断”按钮；诊断记录不包含一次性验证码、私钥或验证码摘要。
- 支持对少数响应 `21` 而非 `20` 的设备尝试继续配置。
- **尚未在你的实体 Google TV 上验证**；如仍无验证码，复制诊断记录有助于识别服务兼容问题。

## v1.1 修复配对码不显示问题

- **关键修正**：Google TV Remote v2 配对请求的 `service_name` 改成协议兼容标识 `atvremote`（原版本错误使用 `qobuz-tv-remote`，可能导致电视拒绝配对请求）。
- 电视端配对流程显示阶段进度：连接 → 配对请求确认 → 验证码格式协商 → 等待 6 位码。
- 新增“检测端口 6467 / 6466”：6467 是配对服务，6466 是遥控服务。端口可连接不代表一定能配对成功，但能帮助确认网络是否通畅。
- 如果**官方 Google TV 遥控器**也无法让电视弹出验证码，优先检查电视系统的 Android TV Remote Service 版本、Wi-Fi 隔离和电视重启，不是 Qobuz API 问题。
- 如果电视仍无验证码，本应用不能跳过电视的配对安全确认。你仍可直接用官方 Qobuz 的 Qobuz Connect 控制电视上的音乐（无需本工具配对）。

## 功能

- mDNS 自动发现电视（`_androidtvremote2._tcp.`），也可输入电视的局域网 IPv4 地址
- 电视上 6 位十六进制验证码配对，证书持久保存，下一次自动重连
- 播放/暂停、上一首、下一首、音量调整、静音
- 电视方向键、确定、返回、主页
- 手机打开官方 Qobuz App；电视尝试用 `market://launch?id=com.qobuz.music` 打开 Qobuz（固件兼容性不保证）
- 记住电视设备名称及 IP；发现同名电视的新 IP 时自动尝试重连
- 中文界面；全本地传输，不收集账号和密码

## 手机/电视准备

1. 手机 Android 8.0+，Google TV/Android TV 安装 Qobuz 并登录。
2. 手机与电视连接同一个 Wi-Fi 或可互访的同一个局域网。
3. 打开本 App，选电视或输入电视 IP，点击“首次配对”。电视出现 6 位代码后输入并确认。
4. 配对完成后，播放控制键即可操纵正在电视上播放的 Qobuz。电视不支持媒体键的个别场景下可用方向键控制。
5. 想在手机直接搜索歌曲：点击“打开手机 Qobuz”，在官方 Qobuz 播放任意歌曲，点“音频输出”选择电视（Qobuz Connect）。

## 使用 GitHub Actions 编译 APK

1. 在 GitHub 登录后打开 https://github.com/new ，新仓库名称建议 **Qobuz-GoogleTV-Remote**，选择 **Public** 或 **Private** 创建。
2. 仓库页点 **Add file → Upload files**；解压本 ZIP 后，把其中全部项目文件/目录上传到仓库**根目录**，确保 `.github/workflows/build-apk.yml` 被上传。
3. 点击 **Commit changes**。如果 Actions 未自动运行，进入 **Actions → Build Qobuz Google TV Remote APK → Run workflow**。
4. 等待工作流构建完成，进入该次运行底部 **Artifacts → Qobuz-TV-Remote-APK**，下载压缩包并解压得到 `app-debug.apk`。
5. 用安卓手机安装 APK。该 APK 是自动签名的 debug 安装包。

**仓库可直接访问的链接（需要替换为你自己的用户名）：**

- 新建仓库：https://github.com/new
- 代码上传页面：`https://github.com/你的用户名/Qobuz-GoogleTV-Remote/upload/main`
- 手动运行与下载 APK：`https://github.com/你的用户名/Qobuz-GoogleTV-Remote/actions`
- 修改编译脚本：`https://github.com/你的用户名/Qobuz-GoogleTV-Remote/edit/main/.github/workflows/build-apk.yml`

### 编译条件

JDK 17、Gradle 8.9、Android Gradle Plugin 8.6.1、compileSdk 35；GitHub Actions 自动安装环境。不需要在本地安装 Gradle 或 Android Studio。

### 安全和兼容注意

- 设备证书在安卓 App 私有目录保存；TV 证书 SHA-256 指纹在配对成功后保存，用于下次识别同一电视。
- 首次 TLS 连接使用电视屏幕上的一次性验证码鉴权；本地网络协议未使用公网服务器。
- 自动发现可能受到 Wi-Fi AP 隔离、VLAN、多播限制影响，失败时手动输入电视 IP。
- “电视启动 Qobuz”通过第三方 Google TV 遥控协议发送启动链接，部分固件无法执行或只会打开应用商店；此时按“主页”，用方向键打开 Qobuz。
- 无法在本 App 内列出 Qobuz 曲库、当前曲名、封面或播放队列；请使用官方 Qobuz Connect。
- Google TV Remote v2 为非公开协议，不同固件/Remote Service 版本可能不兼容。需要在实际设备上测试。未经实体电视测试，源码构建成功不代表所有设备配对可用。

## 版权/依赖

本项目是独立 Java 实现，参考公开的 Android TV Remote v2 互操作文档，使用 Bouncy Castle 1.78.1（见其许可证）。没有嵌入 Qobuz 专有 SDK、密码或非公开 API。
